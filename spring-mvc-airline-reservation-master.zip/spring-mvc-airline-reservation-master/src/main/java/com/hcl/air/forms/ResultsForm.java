package com.hcl.air.forms;

public class ResultsForm {

	private String selectedFlight;
	
	public String getSelectedFlight() {
		return selectedFlight;
	}
	public void setSelectedFlight(String selectedFlight) {
		this.selectedFlight = selectedFlight;
	}
	
}
